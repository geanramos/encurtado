<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico" type="image/x-icon">
  <meta name="description" content="Aproveite vídeos e música que você ama, compartilhe-o com amigos, parentes e o mundo.">
  <?php
  $id = $_GET["v"];
  echo "<title>Gean Ramos - Video | $id</title>";
  ?>
  <link rel="stylesheet" href="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/tether/tether.min.css">
  <link rel="stylesheet" href="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/theme/css/style.css">
  <link rel="stylesheet" href="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/mobirise/css/mbr-additional.css" type="text/css">]
  

</head>
<body>
<div class="a2a_kit a2a_kit_size_32 a2a_floating_style a2a_vertical_style" style="left:0px;top:200px;">

<a class="a2a_button_whatsapp"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_linkedin"></a>
</div>

  <section class="cid-rJl19dnO5v" id="video1-a">

 <center><!-- LOMADEE - BEGIN -->
<a href="http://gean.ml/91k" target="_blank">
<img src="https://i.imgur.com/8mPeerH.png" border="0" width="728" height="90"/></a>

<!-- LOMADEE - END --></center><br>   
    
    <figure class="mbr-figure align-center container">
        <div class="video-block" style="width: 66%;">
            <div><?php
			$id = $_GET["v"];
			echo "<iframe class=\"mbr-embedded-video\" src=\"https://www.youtube-nocookie.com/embed/$id?controls=0\" width=\"1280\" height=\"720\" frameborder=\"0\" allowfullscreen></iframe>";
			?></div>
        </div>
    </figure>
    <br>
    <center><!-- LOMADEE - BEGIN -->
<script src="//ad.lomadee.com/banners/script.js?sourceId=36372699&dimension=1&height=90&width=728&method=0" type="text/javascript" language="javascript"></script>
<!-- LOMADEE - END --></center>
</section>


  <section class="engine"></section>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/web/assets/jquery/jquery.min.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/popper/popper.min.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/tether/tether.min.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/smoothscroll/smooth-scroll.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="https://gitcdn.xyz/cdn/geanramos/18011975/5f4c2ae034082ff40bcc481d69261b57ee98ee0f/yt-assets/theme/js/script.js"></script>
  <script src="//files.u1m.com.br/home-assets/puritym/js/page.js"></script>
  
  
<input name="cookieData" type="hidden"data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-colorButton='#ffffff' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="Utilizamos cookies para proporcionar a melhor experiência. Leia nossa  <a href='https://www.youtube.com/yt/policyandsafety/pt-BR/' target='_blank'>política de cookies</a>.">
<!--Ops-->
  <noscript></body></noscrip>
</html>